# MVBA Tax Sales Scraper

A Python scraper to retrieve all tax deed sales in Texas from MVBA Law Firm (mvbalaw.com and mvbataxsales.com).

## Overview

MVBA Law Firm (McCreary, Veselka, Bragg & Allen) handles delinquent property tax collections and tax deed sales for multiple Texas counties. This scraper retrieves property listings from both their online auction platform and PDF bid sheets.

## Features

- **Scrapes online auctions** from mvbataxsales.com
- **Extracts PDF links** for in-person tax sales from mvbalaw.com
- **Retrieves detailed property information** including:
  - Account numbers
  - Lot numbers
  - Property descriptions
  - Starting bids
  - Suit numbers
  - Case styles
  - Bidding dates
  - Judgment years
- **Handles multiple counties** across Texas
- **Exports data to JSON** format for easy analysis
- **Rate limiting** to be respectful to the servers

## Counties Covered

MVBA handles tax sales for the following Texas counties (as of January 2026):

### Online Auctions (mvbataxsales.com):
- Henderson County
- Gregg County
- Harrison County
- Bowie County
- Comal County
- Cherokee County

### In-Person Sales (PDF format):
- Comanche County
- Jones County

### Other Platforms:
- Smith County (via Real Auction platform)
- McLennan County (via GovEase platform)

## Installation

1. Ensure you have Python 3.7+ installed

2. Install required dependencies:
```bash
pip install -r requirements.txt
```

Or install manually:
```bash
pip install requests beautifulsoup4
```

## Usage

### Basic Usage

Run the scraper:
```bash
python3 mvba_tax_sales_scraper.py
```

This will:
1. Scrape all available tax sales
2. Save results to `mvba_tax_sales.json`
3. Print a summary to the console

### Using as a Module

You can also import and use the scraper in your own Python code:

```python
from mvba_tax_sales_scraper import MVBATaxSalesScraper

# Create scraper instance
scraper = MVBATaxSalesScraper()

# Scrape all data
results = scraper.scrape_all()

# Access the data
pdf_sales = results['pdf_sales']
online_auctions = results['online_auctions']
all_properties = results['all_properties']

# Save to custom filename
scraper.save_results(results, 'my_custom_output.json')
```

### Advanced Usage

Get specific auction properties:
```python
scraper = MVBATaxSalesScraper()

# Get properties from a specific auction URL
auction_url = "https://www.mvbataxsales.com/auction/gregg-county-tax-sale-163/"
properties = scraper.get_auction_properties(auction_url)

for prop in properties:
    print(f"Account: {prop['account_number']}, Bid: ${prop['starting_bid']}")
```

Get only online auctions:
```python
scraper = MVBATaxSalesScraper()
auctions = scraper.get_online_auctions()

for auction in auctions:
    print(f"{auction['title']}: {auction['url']}")
```

## Output Format

The scraper outputs a JSON file with the following structure:

```json
{
  "scraped_at": "2026-01-03T18:30:00",
  "pdf_sales": [
    {
      "county": "Comanche County",
      "url": "https://mvbalaw.com/wp-content/TaxUploads/0126_Comanche.pdf",
      "type": "in_person_pdf"
    }
  ],
  "online_auctions": [
    {
      "title": "GREGG COUNTY ONLINE PROPERTY TAX SALE",
      "url": "https://www.mvbataxsales.com/auction/...",
      "type": "online_auction"
    }
  ],
  "all_properties": [
    {
      "url": "https://www.mvbataxsales.com/auction/.../item/...",
      "lot_number": "0001",
      "account_number": "53708",
      "suit_number": "022313-CCL2",
      "description": "Lots 4 & 5, Block 7, Mallock Addition...",
      "starting_bid": "21595.13",
      "bidding_start": "Tue, Jan 6, 2026 at 10:00:00 am CT",
      "bidding_end": "Tue, Jan 6, 2026 at 02:00:00 pm CT",
      "case_style": "The County of Gregg v John Doe",
      "judgment_year": "2024",
      "auction_title": "GREGG COUNTY ONLINE PROPERTY TAX SALE",
      "auction_url": "https://www.mvbataxsales.com/auction/...",
      "scraped_at": "2026-01-03T18:30:15"
    }
  ]
}
```

## Data Fields

### PDF Sales
- `county`: County name
- `url`: Direct link to the PDF bid sheet
- `type`: Always "in_person_pdf"

### Online Auctions
- `title`: Auction title/name
- `url`: Link to the auction page
- `type`: Always "online_auction"
- `archived`: Boolean indicating if this is a past auction

### Properties
- `url`: Direct link to the property listing
- `lot_number`: Lot number in the auction
- `account_number`: County tax account number
- `suit_number`: Court case number
- `description`: Legal property description
- `starting_bid`: Minimum bid amount (as string)
- `bidding_start`: Auction start date/time
- `bidding_end`: Auction end date/time
- `case_style`: Full case name
- `judgment_year`: Tax year through which judgment applies
- `auction_title`: Parent auction title
- `auction_url`: Parent auction URL
- `scraped_at`: Timestamp when property was scraped

## Important Notes

### Rate Limiting
The scraper includes built-in delays to be respectful to the MVBA servers:
- 0.5 seconds between property requests
- 1 second between auction requests

### PDF Processing
The scraper identifies PDF links but does not parse the PDF content. To extract property data from PDFs, you would need to:
1. Download the PDFs using the URLs provided
2. Use a PDF parsing library like `PyPDF2`, `pdfplumber`, or `tabula-py`
3. Extract the property table data

Example PDF parsing (not included):
```python
import pdfplumber

def parse_pdf(pdf_url):
    # Download and parse PDF
    response = requests.get(pdf_url)
    with open('temp.pdf', 'wb') as f:
        f.write(response.content)
    
    with pdfplumber.open('temp.pdf') as pdf:
        for page in pdf.pages:
            tables = page.extract_tables()
            # Process tables...
```

### Archived Auctions
The scraper retrieves both current and archived auctions. Filter by the `archived` field if you only want active sales.

### Data Accuracy
Property information is extracted using pattern matching from HTML content. While generally reliable, some fields may be missing or incomplete depending on the auction format. Always verify critical information on the official MVBA website.

## Troubleshooting

### No properties found
- Check if there are currently active auctions on mvbataxsales.com
- Verify your internet connection
- The website structure may have changed (check logs for errors)

### Connection errors
- Ensure you have internet access
- The MVBA servers may be temporarily down
- Try increasing timeout values in the code

### Missing data fields
- Not all auctions include all fields
- Check the actual property page to see what information is available
- Some fields may use different formatting

## Legal and Ethical Considerations

- This scraper is for **informational purposes only**
- Always respect the website's terms of service
- Do not overwhelm the servers with excessive requests
- Verify all property information on the official MVBA website before making any decisions
- Tax sales are subject to specific legal requirements - consult with legal counsel before bidding

## Website Structure

### MVBA Law Firm (mvbalaw.com)
- Main tax sales page: https://mvbalaw.com/tax-sales/
- Monthly sales: https://mvbalaw.com/tax-sales/month-sales/
- PDF format: https://mvbalaw.com/wp-content/TaxUploads/[MMDD]_[County].pdf

### MVBA Online Auctions (mvbataxsales.com)
- Main page: https://www.mvbataxsales.com/
- Archive: https://www.mvbataxsales.com/home/archive
- Auction gallery: https://www.mvbataxsales.com/auction/{slug}/bidgallery/
- Property details: https://www.mvbataxsales.com/auction/{slug}/item/{item-slug}/

## License

This code is provided as-is for educational and informational purposes. Use at your own risk.

## Author

Created for retrieving Texas tax deed sales information from MVBA Law Firm websites.

## Version

1.0.0 - January 2026
