#!/usr/bin/env python3
"""
MVBA Tax Sales Scraper - Final Version
Retrieves all tax deed sales in Texas from MVBA Law Firm websites.

This scraper retrieves:
1. PDF listings from mvbalaw.com (in-person sales)
2. Archived auctions from mvbataxsales.com/home/archive
3. Active auctions (manually specified or from known URLs)
4. Property details from each auction's bid gallery
"""

import requests
from bs4 import BeautifulSoup
import json
import re
from datetime import datetime
from typing import List, Dict, Optional
import time
import logging

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class MVBATaxSalesScraper:
    """Scraper for MVBA tax sales in Texas"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        })
        self.base_url_auctions = "https://www.mvbataxsales.com"
        self.base_url_law = "https://mvbalaw.com"
        
        # Known active auction URLs (update these as needed)
        self.known_active_auctions = [
            "https://www.mvbataxsales.com/auction/gladewater-isdcity-of-gladewaterpine-tree-isd-gregg-county-online-property-tax-sale-january-6-2026-163/"
        ]
        
    def get_monthly_sales_page(self) -> Optional[BeautifulSoup]:
        """Get the monthly sales page from mvbalaw.com"""
        url = f"{self.base_url_law}/tax-sales/month-sales/"
        try:
            response = self.session.get(url, timeout=30)
            response.raise_for_status()
            return BeautifulSoup(response.content, 'html.parser')
        except Exception as e:
            logger.error(f"Error fetching monthly sales page: {e}")
            return None
    
    def extract_pdf_links(self, soup: BeautifulSoup) -> List[Dict[str, str]]:
        """Extract PDF links for in-person tax sales"""
        pdf_links = []
        
        if not soup:
            return pdf_links
        
        # Find all links that point to PDF files
        for link in soup.find_all('a', href=True):
            href = link['href']
            if '.pdf' in href.lower() and 'TaxUploads' in href:
                # Extract county name from the link text or URL
                county_name = link.get_text(strip=True)
                if not county_name or county_name == '':
                    # Try to extract from URL
                    match = re.search(r'/(\d{4})_([^.]+)\.pdf', href)
                    if match:
                        county_name = match.group(2)
                
                # Make sure URL is absolute
                if not href.startswith('http'):
                    href = f"{self.base_url_law}{href}" if href.startswith('/') else f"{self.base_url_law}/{href}"
                
                # Extract date from URL if available
                date_match = re.search(r'/(\d{2})(\d{2})_', href)
                sale_date = None
                if date_match:
                    month = date_match.group(1)
                    day = date_match.group(2)
                    sale_date = f"2026-{month}-{day}"  # Assuming current year
                
                pdf_links.append({
                    'county': county_name,
                    'url': href,
                    'type': 'in_person_pdf',
                    'sale_date': sale_date
                })
                logger.info(f"Found PDF for {county_name}: {href}")
        
        return pdf_links
    
    def get_online_auctions_from_archive(self) -> List[Dict[str, any]]:
        """Get all online auctions from the archive page"""
        auctions = []
        
        try:
            archive_url = f"{self.base_url_auctions}/home/archive"
            response = self.session.get(archive_url, timeout=30)
            response.raise_for_status()
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Find auction containers
            auction_containers = soup.find_all(['div', 'section', 'article'])
            
            for container in auction_containers:
                # Look for auction title
                title_elem = container.find(['h2', 'h3', 'h4', 'a'], string=lambda x: x and 'COUNTY' in str(x).upper() and 'TAX SALE' in str(x).upper())
                if title_elem:
                    title = title_elem.get_text(strip=True)
                    # Find the View Results or View Auction link in this container
                    link = container.find('a', string=lambda x: x and ('View Results' in str(x) or 'View Auction' in str(x)))
                    if link:
                        href = link.get('href', '')
                        if '/auction/' in href:
                            # Make sure URL is absolute
                            if not href.startswith('http'):
                                href = f"{self.base_url_auctions}{href}" if href.startswith('/') else f"{self.base_url_auctions}/{href}"
                            
                            # Check if already added
                            if href not in [a.get('url') for a in auctions]:
                                auctions.append({
                                    'title': title,
                                    'url': href,
                                    'type': 'online_auction',
                                    'archived': 'View Results' in link.get_text()
                                })
                                logger.info(f"Found archived auction: {title}")
        
        except Exception as e:
            logger.error(f"Error fetching archived auctions: {e}")
        
        return auctions
    
    def get_known_active_auctions(self) -> List[Dict[str, any]]:
        """Get known active auctions from predefined URLs"""
        auctions = []
        
        for url in self.known_active_auctions:
            try:
                response = self.session.get(url, timeout=30)
                response.raise_for_status()
                soup = BeautifulSoup(response.content, 'html.parser')
                
                # Extract title from page
                title_elem = soup.find(['h1', 'h2'], string=lambda x: x and 'COUNTY' in str(x).upper())
                if title_elem:
                    title = title_elem.get_text(strip=True)
                else:
                    # Try to extract from URL
                    title = url.split('/auction/')[-1].replace('-', ' ').replace('/', '').upper()
                
                auctions.append({
                    'title': title,
                    'url': url,
                    'type': 'online_auction',
                    'archived': False,
                    'status': 'active'
                })
                logger.info(f"Found active auction: {title}")
                
            except Exception as e:
                logger.error(f"Error fetching active auction {url}: {e}")
        
        return auctions
    
    def get_auction_properties(self, auction_url: str) -> List[Dict[str, any]]:
        """Get all properties from a specific auction"""
        properties = []
        
        try:
            # Try multiple URL patterns
            urls_to_try = [
                auction_url.rstrip('/') + '/bidgallery/',
                auction_url.rstrip('/'),
            ]
            
            property_urls = set()
            
            for url in urls_to_try:
                try:
                    response = self.session.get(url, timeout=30)
                    response.raise_for_status()
                    soup = BeautifulSoup(response.content, 'html.parser')
                    
                    # Method 1: Find links with /item/ in href
                    for link in soup.find_all('a', href=lambda x: x and '/item/' in x):
                        href = link.get('href', '')
                        if not href.startswith('http'):
                            href = f"{self.base_url_auctions}{href}" if href.startswith('/') else f"{self.base_url_auctions}/{href}"
                        property_urls.add(href)
                    
                    # Method 2: Extract from JavaScript/JSON data
                    scripts = soup.find_all('script')
                    for script in scripts:
                        script_text = script.string or ''
                        # Look for item URLs in JavaScript
                        item_matches = re.findall(r'/auction/[^/]+/item/[^"\s]+', script_text)
                        for match in item_matches:
                            full_url = f"{self.base_url_auctions}{match}"
                            property_urls.add(full_url)
                    
                    # Method 3: Build URLs from lot numbers if we can find them
                    # Extract auction slug from URL
                    auction_slug_match = re.search(r'/auction/([^/]+)', auction_url)
                    if auction_slug_match:
                        auction_slug = auction_slug_match.group(1)
                        # Look for lot numbers in the page
                        lot_matches = re.findall(r'Lot #?\s*(\d+)', soup.get_text())
                        if lot_matches:
                            logger.info(f"Found {len(set(lot_matches))} lot numbers, attempting to build URLs...")
                            # We can't reliably build URLs without knowing the item slugs
                            # So we'll just note that properties exist
                            pass
                    
                except Exception as e:
                    logger.debug(f"Error trying URL {url}: {e}")
                    continue
            
            logger.info(f"Found {len(property_urls)} property URLs in auction")
            
            # If no URLs found but we know there are properties, log a warning
            if len(property_urls) == 0:
                logger.warning(f"No property URLs found. The auction may use JavaScript to load content.")
                logger.warning(f"You may need to visit {auction_url} in a browser to see properties.")
                return properties
            
            for href in property_urls:
                # Get property details
                property_data = self.get_property_details(href)
                if property_data:
                    properties.append(property_data)
                    logger.info(f"Retrieved property: {property_data.get('account_number', 'Unknown')}")
                
                # Be respectful with rate limiting
                time.sleep(0.5)
        
        except Exception as e:
            logger.error(f"Error fetching auction properties from {auction_url}: {e}")
        
        return properties
    
    def get_property_details(self, property_url: str) -> Optional[Dict[str, any]]:
        """Get detailed information about a specific property"""
        try:
            response = self.session.get(property_url, timeout=30)
            response.raise_for_status()
            soup = BeautifulSoup(response.content, 'html.parser')
            
            page_text = soup.get_text()
            
            # Extract property details
            property_data = {
                'url': property_url,
                'scraped_at': datetime.now().isoformat()
            }
            
            # Extract lot number
            lot_match = re.search(r'Lot #?\s*(\d+)', page_text)
            if lot_match:
                property_data['lot_number'] = lot_match.group(1)
            
            # Extract account number
            account_match = re.search(r'Account No\.?\s*([^\s,:-]+)', page_text)
            if account_match:
                property_data['account_number'] = account_match.group(1)
            
            # Extract suit number
            suit_match = re.search(r'Suit No\.?\s*([^\s,:-]+)', page_text)
            if suit_match:
                property_data['suit_number'] = suit_match.group(1)
            
            # Extract property description - get the full title
            title_elem = soup.find(['h1', 'h2', 'h3', 'h4'], string=lambda x: x and 'Account No' in str(x))
            if title_elem:
                property_data['description'] = title_elem.get_text(strip=True)
            
            # Extract starting bid
            bid_match = re.search(r'Starting Bid[:\s]+\$?([\d,]+\.?\d*)', page_text)
            if bid_match:
                property_data['starting_bid'] = bid_match.group(1).replace(',', '')
            
            # Extract bidding dates
            start_match = re.search(r'Bidding Starts[:\s]+([^\n]+)', page_text)
            if start_match:
                property_data['bidding_start'] = start_match.group(1).strip()
            
            end_match = re.search(r'Bidding Ends[:\s]+([^\n]+)', page_text)
            if end_match:
                property_data['bidding_end'] = end_match.group(1).strip()
            
            # Extract case style
            style_match = re.search(r'([\w\s]+County[^v]+v[^,]+)', page_text)
            if style_match:
                property_data['case_style'] = style_match.group(1).strip()
            
            # Extract judgment year
            judgment_match = re.search(r'Judgment Through Tax Year[:\s]+(\d{4})', page_text)
            if judgment_match:
                property_data['judgment_year'] = judgment_match.group(1)
            
            # Check if withdrawn
            if 'WITHDRAWN FROM TAX SALE' in page_text:
                property_data['status'] = 'withdrawn'
            else:
                property_data['status'] = 'active'
            
            return property_data
        
        except Exception as e:
            logger.error(f"Error fetching property details from {property_url}: {e}")
            return None
    
    def scrape_all(self, include_archived=True, include_active=True) -> Dict[str, any]:
        """Scrape all tax sales from MVBA websites"""
        logger.info("Starting MVBA tax sales scraping...")
        
        results = {
            'scraped_at': datetime.now().isoformat(),
            'pdf_sales': [],
            'online_auctions': [],
            'all_properties': []
        }
        
        # Get PDF links from monthly sales page
        logger.info("Fetching monthly sales page for PDF listings...")
        monthly_soup = self.get_monthly_sales_page()
        pdf_links = self.extract_pdf_links(monthly_soup)
        results['pdf_sales'] = pdf_links
        
        online_auctions = []
        
        # Get known active auctions
        if include_active:
            logger.info("Fetching known active auctions...")
            active_auctions = self.get_known_active_auctions()
            online_auctions.extend(active_auctions)
        
        # Get archived auctions
        if include_archived:
            logger.info("Fetching archived auctions...")
            archived_auctions = self.get_online_auctions_from_archive()
            online_auctions.extend(archived_auctions)
        
        results['online_auctions'] = online_auctions
        
        # Get properties from each online auction
        logger.info(f"Fetching properties from {len(online_auctions)} online auctions...")
        for auction in online_auctions:
            logger.info(f"Processing auction: {auction['title']}")
            properties = self.get_auction_properties(auction['url'])
            
            for prop in properties:
                prop['auction_title'] = auction['title']
                prop['auction_url'] = auction['url']
                prop['auction_archived'] = auction.get('archived', False)
                results['all_properties'].append(prop)
            
            # Be respectful with rate limiting
            time.sleep(1)
        
        logger.info(f"Scraping complete! Found {len(results['pdf_sales'])} PDF sales and {len(results['all_properties'])} online properties")
        
        return results
    
    def save_results(self, results: Dict[str, any], filename: str = 'mvba_tax_sales.json'):
        """Save results to a JSON file"""
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
            logger.info(f"Results saved to {filename}")
        except Exception as e:
            logger.error(f"Error saving results: {e}")


def main():
    """Main function to run the scraper"""
    scraper = MVBATaxSalesScraper()
    
    # Scrape all data (active and archived)
    results = scraper.scrape_all(include_archived=True, include_active=True)
    
    # Save to JSON file
    scraper.save_results(results)
    
    # Print summary
    print("\n" + "="*60)
    print("MVBA TAX SALES SCRAPING SUMMARY")
    print("="*60)
    print(f"PDF Sales Found: {len(results['pdf_sales'])}")
    print(f"Online Auctions Found: {len(results['online_auctions'])}")
    print(f"Total Properties Retrieved: {len(results['all_properties'])}")
    
    # Count active vs withdrawn
    active_count = sum(1 for p in results['all_properties'] if p.get('status') != 'withdrawn')
    withdrawn_count = sum(1 for p in results['all_properties'] if p.get('status') == 'withdrawn')
    print(f"  - Active Properties: {active_count}")
    print(f"  - Withdrawn Properties: {withdrawn_count}")
    print("="*60)
    
    # Print PDF sales
    if results['pdf_sales']:
        print("\nPDF SALES:")
        for pdf in results['pdf_sales']:
            date_str = f" (Sale Date: {pdf.get('sale_date', 'N/A')})" if pdf.get('sale_date') else ""
            print(f"  - {pdf['county']}{date_str}")
            print(f"    {pdf['url']}")
    
    # Print online auctions
    if results['online_auctions']:
        print("\nONLINE AUCTIONS:")
        for auction in results['online_auctions']:
            status = " (ARCHIVED)" if auction.get('archived') else " (ACTIVE)"
            print(f"  - {auction['title']}{status}")
    
    # Print sample properties
    if results['all_properties']:
        print(f"\nSAMPLE PROPERTIES (showing first 5 of {len(results['all_properties'])}):")
        for prop in results['all_properties'][:5]:
            status_str = f" [{prop.get('status', 'unknown').upper()}]" if prop.get('status') else ""
            print(f"\n  Lot #{prop.get('lot_number', 'N/A')}{status_str}")
            print(f"  Account: {prop.get('account_number', 'N/A')}")
            print(f"  Starting Bid: ${prop.get('starting_bid', 'N/A')}")
            print(f"  Auction: {prop.get('auction_title', 'N/A')}")
            if prop.get('description'):
                desc = prop['description'][:100] + "..." if len(prop.get('description', '')) > 100 else prop.get('description', '')
                print(f"  Description: {desc}")
    
    print("\n" + "="*60)
    print(f"Full results saved to: mvba_tax_sales.json")
    print("="*60)
    print("\nNOTE: To add more active auctions, edit the 'known_active_auctions'")
    print("list in the MVBATaxSalesScraper class with current auction URLs.")


if __name__ == "__main__":
    main()
