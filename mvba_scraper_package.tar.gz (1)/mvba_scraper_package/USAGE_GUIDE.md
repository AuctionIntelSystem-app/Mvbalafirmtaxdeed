# MVBA Tax Sales Scraper - Usage Guide

## Quick Start

The simplest way to retrieve all tax deed sales from MVBA:

```bash
python3 mvba_tax_sales_scraper_final.py
```

This will create a file called `mvba_tax_sales.json` with all the data.

## What Gets Scraped

The scraper retrieves three types of tax sale information:

### 1. PDF Listings (In-Person Sales)
- **Source**: https://mvbalaw.com/tax-sales/month-sales/
- **Format**: PDF files with property tables
- **Counties**: Comanche, Jones, and others
- **What you get**: PDF URLs and county names

### 2. Online Auctions
- **Source**: https://www.mvbataxsales.com/
- **Format**: Web-based auction platform
- **Counties**: Gregg, Henderson, Harrison, Bowie, Cherokee, Comal, and others
- **What you get**: Full property details including bids, dates, descriptions

### 3. Archived Auctions
- **Source**: https://www.mvbataxsales.com/home/archive
- **Format**: Past online auctions
- **What you get**: Historical auction data and results

## Understanding the Output

The scraper creates a JSON file with this structure:

```json
{
  "scraped_at": "2026-01-03T18:30:00",
  "pdf_sales": [...],
  "online_auctions": [...],
  "all_properties": [...]
}
```

### PDF Sales
Each PDF sale entry contains:
- `county`: County name
- `url`: Direct link to download the PDF
- `type`: Always "in_person_pdf"
- `sale_date`: Date of the sale (if available)

### Online Auctions
Each auction entry contains:
- `title`: Full auction title
- `url`: Link to the auction page
- `type`: Always "online_auction"
- `archived`: true/false
- `status`: "active" or "archived"

### Properties
Each property entry contains:
- `lot_number`: Lot number in the auction
- `account_number`: County tax account number
- `suit_number`: Court case number
- `description`: Full legal property description
- `starting_bid`: Minimum bid amount
- `bidding_start`: Auction start date/time
- `bidding_end`: Auction end date/time
- `case_style`: Full case name
- `judgment_year`: Tax year
- `status`: "active" or "withdrawn"
- `auction_title`: Which auction this property belongs to
- `url`: Direct link to property page

## Important Limitations

### JavaScript-Loaded Content

The mvbataxsales.com homepage uses JavaScript to dynamically load current auction listings. This means:

**What works:**
- ✅ PDF listings from mvbalaw.com
- ✅ Archived auctions from the archive page
- ✅ Property details from known auction URLs

**What doesn't work automatically:**
- ❌ Detecting NEW active auctions on the homepage

**Solution:**
When a new auction appears on mvbataxsales.com, you need to manually add its URL to the scraper.

### How to Add New Active Auctions

1. Visit https://www.mvbataxsales.com/ in a web browser
2. Find the "View Auction" button for the new auction
3. Right-click and copy the link address
4. Open `mvba_tax_sales_scraper_final.py`
5. Find the `known_active_auctions` list (around line 45)
6. Add the new URL to the list:

```python
self.known_active_auctions = [
    "https://www.mvbataxsales.com/auction/existing-auction-123/",
    "https://www.mvbataxsales.com/auction/new-auction-456/",  # Add new ones here
]
```

7. Run the scraper again

## Advanced Usage

### Scrape Only Active Auctions

```python
from mvba_tax_sales_scraper_final import MVBATaxSalesScraper

scraper = MVBATaxSalesScraper()
results = scraper.scrape_all(include_archived=False, include_active=True)
scraper.save_results(results, 'active_only.json')
```

### Scrape Only Archived Auctions

```python
results = scraper.scrape_all(include_archived=True, include_active=False)
scraper.save_results(results, 'archived_only.json')
```

### Get Properties from a Specific Auction

```python
scraper = MVBATaxSalesScraper()
auction_url = "https://www.mvbataxsales.com/auction/gregg-county-163/"
properties = scraper.get_auction_properties(auction_url)

for prop in properties:
    print(f"{prop['account_number']}: ${prop['starting_bid']}")
```

### Get Only PDF Links

```python
scraper = MVBATaxSalesScraper()
soup = scraper.get_monthly_sales_page()
pdfs = scraper.extract_pdf_links(soup)

for pdf in pdfs:
    print(f"{pdf['county']}: {pdf['url']}")
```

## Working with PDF Files

The scraper provides PDF URLs but doesn't parse the PDF content. To extract property data from PDFs:

### Option 1: Manual Download
```bash
wget https://mvbalaw.com/wp-content/TaxUploads/0126_Comanche.pdf
```

### Option 2: Python PDF Parsing

Install a PDF library:
```bash
pip3 install pdfplumber
```

Parse the PDF:
```python
import pdfplumber
import requests

# Download PDF
pdf_url = "https://mvbalaw.com/wp-content/TaxUploads/0126_Comanche.pdf"
response = requests.get(pdf_url)

with open('temp.pdf', 'wb') as f:
    f.write(response.content)

# Extract tables
with pdfplumber.open('temp.pdf') as pdf:
    for page in pdf.pages:
        tables = page.extract_tables()
        for table in tables:
            for row in table:
                print(row)
```

## Filtering and Analyzing Data

### Find Properties by County

```python
import json

with open('mvba_tax_sales.json', 'r') as f:
    data = json.load(f)

gregg_properties = [
    p for p in data['all_properties']
    if 'GREGG' in p.get('auction_title', '').upper()
]

print(f"Found {len(gregg_properties)} properties in Gregg County")
```

### Find Properties Under a Certain Bid Amount

```python
cheap_properties = [
    p for p in data['all_properties']
    if p.get('starting_bid') and float(p['starting_bid']) < 5000
]

for prop in cheap_properties:
    print(f"{prop['account_number']}: ${prop['starting_bid']}")
```

### Find Active (Not Withdrawn) Properties

```python
active_properties = [
    p for p in data['all_properties']
    if p.get('status') != 'withdrawn'
]

print(f"{len(active_properties)} active properties")
```

### Export to CSV

```python
import csv
import json

with open('mvba_tax_sales.json', 'r') as f:
    data = json.load(f)

with open('properties.csv', 'w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=[
        'lot_number', 'account_number', 'starting_bid',
        'status', 'auction_title', 'url'
    ])
    writer.writeheader()
    
    for prop in data['all_properties']:
        writer.writerow({
            'lot_number': prop.get('lot_number', ''),
            'account_number': prop.get('account_number', ''),
            'starting_bid': prop.get('starting_bid', ''),
            'status': prop.get('status', ''),
            'auction_title': prop.get('auction_title', ''),
            'url': prop.get('url', '')
        })

print("Exported to properties.csv")
```

## Scheduling Automatic Scraping

### Using Cron (Linux/Mac)

Run the scraper daily at 6 AM:

```bash
crontab -e
```

Add this line:
```
0 6 * * * cd /path/to/scraper && python3 mvba_tax_sales_scraper_final.py
```

### Using Windows Task Scheduler

1. Open Task Scheduler
2. Create Basic Task
3. Set trigger (e.g., Daily at 6:00 AM)
4. Action: Start a program
5. Program: `python`
6. Arguments: `C:\path\to\mvba_tax_sales_scraper_final.py`

## Troubleshooting

### "403 Forbidden" Error

The website is blocking your requests. Try:
- Adding more realistic headers
- Increasing delays between requests
- Using a different IP address or VPN

### "No properties found"

The auction may use JavaScript to load content. Try:
- Visiting the auction URL in a browser to confirm properties exist
- Adding the auction URL to `known_active_auctions`
- Using the manual URL script (see below)

### "Connection timeout"

The website may be slow or down. Try:
- Increasing the timeout value in the code
- Running the scraper at a different time
- Checking if the website is accessible in a browser

## Manual Property URL Script

If the scraper can't automatically find property URLs (due to JavaScript), use the manual script:

1. Visit the auction in a browser
2. Copy all property URLs
3. Edit `mvba_manual_urls.py` and add the URLs
4. Run: `python3 mvba_manual_urls.py`

This will scrape just those specific properties.

## Rate Limiting and Ethics

The scraper includes built-in delays to be respectful:
- 0.5 seconds between property requests
- 1 second between auction requests

**Please:**
- Don't remove these delays
- Don't run multiple instances simultaneously
- Don't scrape more frequently than necessary
- Respect the website's terms of service

## Getting Help

If you encounter issues:

1. Check the log output for error messages
2. Verify the website is accessible in a browser
3. Ensure you have the latest version of the scraper
4. Check if the website structure has changed

## Legal Disclaimer

This scraper is for informational purposes only. Always:
- Verify information on the official MVBA website
- Consult with legal counsel before bidding
- Understand tax sale laws and requirements
- Follow all bidding procedures and requirements

Tax deed sales have specific legal requirements and redemption periods. Do not rely solely on scraped data for investment decisions.
